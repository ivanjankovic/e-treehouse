```
May                               ~ 12H
_______________________________________   

Ruby Basics                   - 169 min   
Ruby Collections              - 106 min   
Ruby Loops                    -  79 min   
Ruby Objects and Classes      - 121 min   
Ruby Blocks                   -  96 min   
Build an Address Book in Ruby - 109 min   
Ruby Gems                     -  48 min
_______________________________________

```

```
Jun                                ~ 3H
_______________________________________   

Introduction to Git           - 186 min
_______________________________________   

```

```
July                              ~ 15H
_______________________________________   

Git Branches and Merging      - 101 min   
GitHub Basics                 - 139 min   
Ruby Modules                  - 120 min   
Ruby Core & Standard Library  - 121 min   
Introduction to Algorithms    - 134 min   
Introduction Data Structures  - 163 min   
Algorithm Sorting & Searching - 119 min
_______________________________________ 

```

```
Aug                              ~ ?H
_______________________________________

Python Basics                 - 234 min
Functional Python             - 158 min
_______________________________________

```

<img width="1199" alt="0719" src="https://user-images.githubusercontent.com/13816039/61189088-436b1400-a656-11e9-8626-7b569f346073.png">  


NEXT
https://teamtreehouse.com/library/type:course/q:python 
https://teamtreehouse.com/library/python-basics-3 
https://teamtreehouse.com/library/functional-python 
https://teamtreehouse.com/library/write-better-python 


Ruby:  
https://teamtreehouse.com/library/type:course/q:ruby  
https://teamtreehouse.com/library/ruby-on-rails-5-basics  

Rest:  
https://teamtreehouse.com/library/asynchronous-programming-with-javascript  
https://teamtreehouse.com/library/prototyping-with-adobe-xd  
https://teamtreehouse.com/library/design-systems  
https://teamtreehouse.com/library/your-first-c-program  

