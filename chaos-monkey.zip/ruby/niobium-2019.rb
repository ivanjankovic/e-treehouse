def solution(a)
  # check if the row has same elements
  # if yes increment the count
  # return count
end