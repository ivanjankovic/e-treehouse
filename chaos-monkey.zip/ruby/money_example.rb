require 'money'

money = Money.new(1000, 'USD')

puts money.inspect